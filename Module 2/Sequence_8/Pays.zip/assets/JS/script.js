const API_URL = "https://restcountries.com/v3.1/all?fields=name,capital,region,population,flags";
const loadBtn = document.getElementById("load-btn");
const searchInput = document.getElementById("search-input");
const statusEl = document.getElementById("status");
const countriesContainer = document.getElementById("countries");

// Tableau qui contiendra tous les pays récupérés
let allCountries = [];

// Quand on clique sur "Charger les pays"
loadBtn.addEventListener("click", () => {
    fetchCountries();
});

// Filtre en direct sur le nom du pays
searchInput.addEventListener("input", () => {
    const term = searchInput.value.toLowerCase().trim();
    const filtered = allCountries.filter((country) => {
        const name = country.name?.common?.toLowerCase() ?? "";
        return name.includes(term);
    });
    renderCountries(filtered);
});
async function fetchCountries() {
    statusEl.textContent = "Chargement en cours...";
    countriesContainer.innerHTML = "";
    loadBtn.disabled = true;
    try {
        const response = await fetch(API_URL);
        if (!response.ok) {
            throw new Error("Erreur HTTP : " + response.status);
        }
        const data = await response.json();
        allCountries = data;
        statusEl.textContent = `Pays chargés : ${allCountries.length}`;
        renderCountries(allCountries);
    } catch (error) {
        console.error(error);
        statusEl.textContent =
            "Une erreur est survenue lors du chargement des pays.";
    } finally {
        loadBtn.disabled = false;
    }
}

// Affiche une liste de pays dans le DOM
function renderCountries(countries) {
    countriesContainer.innerHTML = "";
    if (!countries || countries.length === 0) {
        countriesContainer.textContent = "Aucun pays à afficher.";
        return;
    }
    countries.forEach((country) => {
        const card = document.createElement("article");
        card.className = "country-card";
        const name = country.name?.common ?? "Nom inconnu";
        const officialName = country.name?.official ?? "";
        const capital = country.capital?.[0] ?? "Capitale inconnue";
        const region = country.region ?? "Région inconnue";
        const population =
            country.population?.toLocaleString("fr-FR") ?? "N/A";
        const flagUrl = country.flags?.png ?? "";
        card.innerHTML = `
    ${flagUrl
                ? `<img src="${flagUrl}" alt="Drapeau de ${name}" />`
                : ""
            }
    <h2 class="country-name">${name}</h2>
    ${officialName && officialName !== name
                ? `<p class="country-meta"><em>${officialName}</em></p>`
                : ""
            }
    <p class="country-meta"><strong>Capitale :</strong> ${capital}</p>
    <p class="country-meta"><strong>Région :</strong> ${region}</p>
    <p class="country-meta"><strong>Population :</strong> ${population} habitants</p>
  `;
        countriesContainer.appendChild(card);
    });
}

// Option : charger automatiquement au démarrage
fetchCountries();